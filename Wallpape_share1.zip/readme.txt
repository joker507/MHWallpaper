## 注意：
只能在 win10中运行
显示设置为100%,分辨率为1920*1080
出现壁纸不动：可能是光标选中了终端中的文字，打开play终端，右键即可。


## 使用：
1. 在此目录下(和ffplay.exe、Wallpaper.exe 同目录)存放: 视频.mp4
2. 打开程序 双击Wallpaper.exe（有声版本）、双击Wallpaper_noaudio.exe（无声版本）、延迟有声版本（Wallpaper_slppe2）
3. 关闭：关闭ffplay终端即可

## 更换视频：
视频.mp4
## 偷B站视频：使用python 库 you-get,自行百度
## 开机启动
将快捷方式放在
win+r 输入 shell:startup 打开的文件夹中 

## 更改终端样式：
创建快捷方式，右键属性，即可随意更改


## 致谢: 迷糊老师
// 参考代码：https://www.bilibili.com/video/BV1HZ4y1978a
// 参考代码：https://blog.csdn.net/XIeTTTT/article/details/119190669
